# Ценник

Android-приложение «Ценник» — локальный радар цен: сканирование штрихкода, карточка товара, пользовательские цены, история и оценка выгодности.

## V1

- Kotlin + Jetpack Compose + Material 3
- Room/SQLite
- CameraX + ML Kit Barcode Scanning
- EAN-13 / EAN-8 / UPC-A / UPC-E
- Open Food Facts для метаданных товара
- локальный кэш товаров и цен
- ручное создание товара
- история цен: минимум / максимум / средняя / текущая
- оценка цены: 🔥 очень выгодно / 🟢 выгодно / 🟡 обычно / 🔴 дорого
- цена за кг / л / штуку, если количество и единица известны
- избранное
- поиск по товарам
- список покупок
- PriceAlert для будущих уведомлений о целевой цене
- работа ранее сохранённых данных без интернета

## Архитектура

`Compose UI → ViewModel → Repository → Room / Open Food Facts API`

Сетевой источник используется только для метаданных товара. Реальные цены не генерируются: их вводит пользователь.

## Требования

- JDK 17
- Android SDK 36
- Gradle 8.13
- Android Gradle Plugin 8.13.2

## Сборка

```bash
./gradlew assembleRelease
```

APK появится в:

```text
app/build/outputs/apk/release/app-release.apk
```

Для локального запуска потребуется доступ к Gradle distribution при первом запуске wrapper.

## GitHub Actions

Workflow находится в `.github/workflows/android.yml`.

CI:

1. устанавливает JDK 17;
2. поднимает Gradle 8.13;
3. устанавливает Android SDK 36 и Build Tools 36.0.0;
4. генерирует Gradle Wrapper;
5. запускает `./gradlew assembleRelease`;
6. загружает artifact `cenik-release-apk`.

## API

Open Food Facts: `https://world.openfoodfacts.org/`.

Приложение запрашивает только данные карточки товара по barcode. Цены магазинов не берутся из Open Food Facts.

## Roadmap

### V2

- уведомления по `PriceAlert`;
- сравнение магазинов;
- история покупок;
- статистика расходов;
- полноценная корзина;
- подключение разрешённых API магазинов;
- экспорт/импорт данных.
