package ru.cenik.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY updatedAt DESC") fun observeAll(): Flow<List<ProductEntity>>
    @Query("SELECT * FROM products WHERE favorite = 1 ORDER BY updatedAt DESC") fun observeFavorites(): Flow<List<ProductEntity>>
    @Query("SELECT * FROM products WHERE id = :id LIMIT 1") fun observeById(id: Long): Flow<ProductEntity?>
    @Query("SELECT * FROM products WHERE barcode = :barcode LIMIT 1") suspend fun findByBarcode(barcode: String): ProductEntity?
    @Query("SELECT * FROM products WHERE id = :id LIMIT 1") suspend fun getById(id: Long): ProductEntity?
    @Query("SELECT * FROM products WHERE name LIKE '%' || :query || '%' OR barcode LIKE '%' || :query || '%' OR brand LIKE '%' || :query || '%' ORDER BY updatedAt DESC") fun search(query: String): Flow<List<ProductEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(product: ProductEntity): Long
    @Update suspend fun update(product: ProductEntity)
    @Query("DELETE FROM products WHERE id = :id") suspend fun delete(id: Long)
}

@Dao
interface PriceDao {
    @Query("SELECT * FROM price_records WHERE productId = :productId ORDER BY date DESC") fun observeForProduct(productId: Long): Flow<List<PriceRecordEntity>>
    @Query("SELECT * FROM price_records WHERE productId = :productId ORDER BY date DESC") suspend fun getForProduct(productId: Long): List<PriceRecordEntity>
    @Query("SELECT AVG(price) FROM price_records WHERE productId = :productId") fun observeAverage(productId: Long): Flow<Double?>
    @Insert suspend fun insert(record: PriceRecordEntity): Long
    @Update suspend fun update(record: PriceRecordEntity)
    @Delete suspend fun delete(record: PriceRecordEntity)
}

@Dao
interface PriceAlertDao {
    @Query("SELECT * FROM price_alerts WHERE productId = :productId LIMIT 1") fun observeForProduct(productId: Long): Flow<PriceAlertEntity?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(alert: PriceAlertEntity): Long
}

@Dao
interface ShoppingListDao {
    @Query("SELECT * FROM shopping_list_items ORDER BY completed ASC, id DESC") fun observeAll(): Flow<List<ShoppingListItemEntity>>
    @Insert suspend fun insert(item: ShoppingListItemEntity): Long
    @Update suspend fun update(item: ShoppingListItemEntity)
    @Delete suspend fun delete(item: ShoppingListItemEntity)
}
