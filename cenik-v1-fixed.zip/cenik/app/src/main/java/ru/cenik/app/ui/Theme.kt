package ru.cenik.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF7CFF6B),
    onPrimary = Color(0xFF092006),
    secondary = Color(0xFFB7D9AF),
    surface = Color(0xFF101214),
    background = Color(0xFF0B0D10),
    surfaceVariant = Color(0xFF1A1E22),
    onSurfaceVariant = Color(0xFFB7BDC5)
)

@Composable
fun CenikTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkScheme else DarkScheme, content = content)
}
