package ru.cenik.app.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class CenikRepository(
    private val db: AppDatabase,
    private val api: OpenFoodFactsApi
) {
    fun observeProducts(): Flow<List<ProductEntity>> = db.productDao().observeAll()
    fun observeFavorites(): Flow<List<ProductEntity>> = db.productDao().observeFavorites()
    fun observeProduct(id: Long): Flow<ProductEntity?> = db.productDao().observeById(id)
    fun searchProducts(q: String): Flow<List<ProductEntity>> = db.productDao().search(q)
    fun observePrices(productId: Long): Flow<List<PriceRecordEntity>> = db.priceDao().observeForProduct(productId)
    fun observeShopping(): Flow<List<ShoppingListItemEntity>> = db.shoppingDao().observeAll()
    fun observeAlert(productId: Long): Flow<PriceAlertEntity?> = db.alertDao().observeForProduct(productId)

    suspend fun productByBarcode(barcode: String): ProductEntity? = db.productDao().findByBarcode(barcode)
    suspend fun saveProduct(product: ProductEntity): Long = if (product.id == 0L) db.productDao().insert(product) else { db.productDao().update(product); product.id }

    suspend fun lookupRemote(barcode: String): ProductEntity? {
        return try {
            val response = api.getProduct(barcode)
            val p = response.product ?: return null
            if (response.status != 1 || p.productName.isNullOrBlank()) return null
            val parsed = parseQuantity(p.quantity)
            ProductEntity(
                barcode = barcode,
                name = p.productName.trim(),
                brand = p.brands?.substringBefore(",")?.trim()?.takeIf { it.isNotBlank() },
                category = p.categories?.substringBefore(",")?.trim()?.takeIf { it.isNotBlank() },
                quantity = parsed?.first,
                unit = parsed?.second,
                imageUrl = p.imageUrl
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun addPrice(productId: Long, price: Double, store: String, date: Long, note: String?) {
        db.priceDao().insert(PriceRecordEntity(productId = productId, price = price, store = store, date = date, note = note))
    }
    suspend fun toggleFavorite(product: ProductEntity) = db.productDao().update(product.copy(favorite = !product.favorite, updatedAt = System.currentTimeMillis()))
    suspend fun setAlert(productId: Long, target: Double, enabled: Boolean) = db.alertDao().upsert(PriceAlertEntity(productId = productId, targetPrice = target, enabled = enabled))
    suspend fun addShopping(item: ShoppingListItemEntity) = db.shoppingDao().insert(item)
    suspend fun updateShopping(item: ShoppingListItemEntity) = db.shoppingDao().update(item)
    suspend fun deleteShopping(item: ShoppingListItemEntity) = db.shoppingDao().delete(item)

    private fun parseQuantity(raw: String?): Pair<Double, String>? {
        if (raw.isNullOrBlank()) return null
        val normalized = raw.lowercase().replace(',', '.')
        val regex = Regex("(\\d+(?:\\.\\d+)?)\\s*(kg|g|l|ml|cl|шт|pcs|piece)")
        val match = regex.find(normalized) ?: return null
        val value = match.groupValues[1].toDoubleOrNull() ?: return null
        return value to match.groupValues[2]
    }
}
