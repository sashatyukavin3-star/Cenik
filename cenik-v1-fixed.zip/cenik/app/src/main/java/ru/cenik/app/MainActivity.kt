package ru.cenik.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import ru.cenik.app.ui.CenikApp
import ru.cenik.app.ui.CenikTheme
import ru.cenik.app.ui.CenikViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: CenikViewModel by viewModels { CenikViewModel.Factory((application as CenikApp).container.repository) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CenikTheme { CenikApp(viewModel) } }
    }
}
