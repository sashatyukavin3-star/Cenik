package ru.cenik.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil3.compose.AsyncImage
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.flow.collectLatest
import ru.cenik.app.data.*
import java.text.SimpleDateFormat
import java.util.*

private enum class Screen { HOME, PRODUCTS, FAVORITES, SHOPPING, SCANNER, DETAIL, MANUAL }

@Composable
fun CenikApp(viewModel: CenikViewModel) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selectedId by remember { mutableLongStateOf(0L) }
    var barcodeForManual by remember { mutableStateOf("") }
    var cameraAllowed by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> cameraAllowed = granted; if (granted) screen = Screen.SCANNER }
    val products by viewModel.products.collectAsState(initial = emptyList())
    val shopping by viewModel.shopping.collectAsState(initial = emptyList())

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        AnimatedContent(targetState = screen, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "screen") { s ->
            when (s) {
                Screen.HOME -> HomeScreen(
                    products = products,
                    shoppingCount = shopping.count { !it.completed },
                    onScan = { if (ContextCompat.checkSelfPermission(LocalContext.current, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) { cameraAllowed = true; screen = Screen.SCANNER } else permissionLauncher.launch(Manifest.permission.CAMERA) },
                    onProduct = { selectedId = it; screen = Screen.DETAIL },
                    onProducts = { screen = Screen.PRODUCTS },
                    onFavorites = { screen = Screen.FAVORITES },
                    onShopping = { screen = Screen.SHOPPING }
                )
                Screen.PRODUCTS -> ProductListScreen(products, "Все товары", onBack = { screen = Screen.HOME }, onProduct = { selectedId = it; screen = Screen.DETAIL })
                Screen.FAVORITES -> {
                    val favorites by viewModel.favorites.collectAsState(initial = emptyList())
                    ProductListScreen(favorites, "Избранное", onBack = { screen = Screen.HOME }, onProduct = { selectedId = it; screen = Screen.DETAIL })
                }
                Screen.SHOPPING -> ShoppingScreen(shopping, onBack = { screen = Screen.HOME }, onToggle = { viewModel.updateShopping(it.copy(completed = !it.completed)) }, onDelete = viewModel::deleteShopping)
                Screen.SCANNER -> ScannerScreen(
                    enabled = cameraAllowed,
                    onBack = { screen = Screen.HOME },
                    onBarcode = { code ->
                        viewModel.loadBarcode(code) { id ->
                            if (id != null) { selectedId = id; screen = Screen.DETAIL }
                            else { barcodeForManual = code; screen = Screen.MANUAL }
                        }
                    }
                )
                Screen.DETAIL -> ProductDetailScreen(
                    viewModel = viewModel,
                    productId = selectedId,
                    onBack = { screen = Screen.HOME }
                )
                Screen.MANUAL -> ManualProductScreen(
                    barcode = barcodeForManual,
                    onBack = { screen = Screen.HOME },
                    onSave = { name, brand, qty, unit -> viewModel.createManual(barcodeForManual, name, brand, qty, unit) { selectedId = it; screen = Screen.DETAIL } }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(products: List<ProductEntity>, shoppingCount: Int, onScan: () -> Unit, onProduct: (Long) -> Unit, onProducts: () -> Unit, onFavorites: () -> Unit, onShopping: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Ценник", fontSize = 30.sp, fontWeight = FontWeight.Black); Text("Личный радар цен", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            IconButton(onClick = onFavorites) { Icon(Icons.Default.FavoriteBorder, null) }
            IconButton(onClick = onShopping) { BadgedBox(badge = { if (shoppingCount > 0) Badge { Text(shoppingCount.toString()) } }) { Icon(Icons.Default.ShoppingCart, null) } }
        }
        Spacer(Modifier.height(22.dp))
        Button(onClick = onScan, modifier = Modifier.fillMaxWidth().height(68.dp), shape = RoundedCornerShape(22.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)) {
            Icon(Icons.Default.QrCodeScanner, null); Spacer(Modifier.width(12.dp)); Text("СКАНИРОВАТЬ", fontWeight = FontWeight.Black, fontSize = 18.sp)
        }
        Spacer(Modifier.height(16.dp))
        Text("Последние товары", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (products.isEmpty()) EmptyState("Сканируй товар — он появится здесь")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
            items(products.take(8), key = { it.id }) { ProductRow(it, onProduct) }
        }
        TextButton(onClick = onProducts, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Все товары →") }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ProductRow(product: ProductEntity, onClick: (Long) -> Unit) {
    Card(onClick = { onClick(product.id) }, shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!product.imageUrl.isNullOrBlank()) AsyncImage(model = product.imageUrl, contentDescription = null, modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)))
            else Box(Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface), contentAlignment = Alignment.Center) { Icon(Icons.Default.Inventory2, null, tint = MaterialTheme.colorScheme.primary) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(product.name, fontWeight = FontWeight.SemiBold, maxLines = 2); Text(listOfNotNull(product.brand, product.quantity?.let { "${fmt(it)} ${product.unit ?: ""}" }).joinToString(" · "), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }
            Icon(if (product.favorite) Icons.Default.Favorite else Icons.Default.ChevronRight, null, tint = if (product.favorite) Color(0xFFFF6B7A) else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ProductListScreen(products: List<ProductEntity>, title: String, onBack: () -> Unit, onProduct: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(products, query) {
        val q = query.trim().lowercase()
        if (q.isBlank()) products else products.filter {
            it.name.lowercase().contains(q) || it.barcode.contains(q) || (it.brand?.lowercase()?.contains(q) == true)
        }
    }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } })
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            leadingIcon = { Icon(Icons.Default.Search, null) },
            placeholder = { Text("Название, бренд или barcode") },
            singleLine = true, shape = RoundedCornerShape(16.dp)
        )
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (filtered.isEmpty()) item { EmptyState(if (query.isBlank()) "Здесь пока пусто" else "Ничего не найдено") }
            items(filtered, key = { it.id }) { ProductRow(it, onProduct) }
        }
    }
}

@Composable
private fun ProductDetailScreen(viewModel: CenikViewModel, productId: Long, onBack: () -> Unit) {
    val product by viewModel.product(productId).collectAsState(initial = null)
    val prices by viewModel.prices(productId).collectAsState(initial = emptyList())
    val alert by viewModel.alert(productId).collectAsState(initial = null)
    var showAdd by remember { mutableStateOf(false) }
    var showAlert by remember { mutableStateOf(false) }
    val p = product ?: return

    val avg = prices.map { it.price }.average().takeIf { prices.isNotEmpty() }
    val current = prices.maxByOrNull { it.date }?.price
    val assessment = assess(current, avg)

    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Товар", fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }, actions = { IconButton(onClick = { viewModel.toggleFavorite(p) }) { Icon(if (p.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (p.favorite) Color(0xFFFF6B7A) else LocalContentColor.current) } })
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (!p.imageUrl.isNullOrBlank()) AsyncImage(model = p.imageUrl, contentDescription = null, modifier = Modifier.size(92.dp).clip(RoundedCornerShape(18.dp)))
                            else Box(Modifier.size(92.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface), contentAlignment = Alignment.Center) { Icon(Icons.Default.Inventory2, null, modifier = Modifier.size(38.dp)) }
                            Spacer(Modifier.width(14.dp)); Column { Text(p.name, fontSize = 22.sp, fontWeight = FontWeight.Black); Text(p.brand ?: "Без бренда", color = MaterialTheme.colorScheme.onSurfaceVariant); Text("${p.barcode}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp) }
                        }
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("Минимум", prices.minOfOrNull { it.price })
                            StatCard("Средняя", avg)
                            StatCard("Макс.", prices.maxOfOrNull { it.price })
                        }
                        if (current != null) {
                            Spacer(Modifier.height(14.dp)); Text("${fmtMoney(current)} ₽", fontSize = 40.sp, fontWeight = FontWeight.Black)
                            Text(assessment.first, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = assessment.second)
                            if (avg != null) Text("${if (current < avg) "Ниже" else "Выше"} средней на ${kotlin.math.abs((current - avg) / avg * 100).round1()}%", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else Text("Цена пока не добавлена", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        unitPrice(current, p)?.let { Text("${fmtMoney(it)} ₽ / ${if (p.unit.equals("ml", true)) "л" else if (p.unit.equals("g", true)) "кг" else p.unit ?: "шт"}", modifier = Modifier.padding(top = 6.dp), fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
            item { Button(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Добавить цену") } }
            item { OutlinedButton(onClick = { viewModel.addShopping(p) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(18.dp)) { Icon(Icons.Default.AddShoppingCart, null); Spacer(Modifier.width(8.dp)); Text("В список покупок") } }
            item { OutlinedButton(onClick = { showAlert = true }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(18.dp)) { Icon(Icons.Default.NotificationsNone, null); Spacer(Modifier.width(8.dp)); Text(if (alert?.enabled == true) "Будильник: ≤ ${fmtMoney(alert?.targetPrice ?: 0.0)} ₽" else "Поставить ценовой будильник") } }
            item { Text("История цен", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
            items(prices, key = { it.id }) { r -> PriceRow(r, p, avg) }
        }
    }
    if (showAdd) AddPriceDialog(onDismiss = { showAdd = false }) { price, store, note -> viewModel.addPrice(p.id, price, store, note); showAdd = false }
    if (showAlert) AlertDialogPrice(initial = alert?.targetPrice, enabled = alert?.enabled == true, onDismiss = { showAlert = false }) { target, enabled -> viewModel.setAlert(p.id, target, enabled); showAlert = false }
}

@Composable private fun StatCard(label: String, value: Double?) { Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) { Column(Modifier.padding(12.dp).widthIn(min = 90.dp)) { Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value?.let(::fmtMoney) ?: "—", fontWeight = FontWeight.Bold) } } }

@Composable private fun PriceRow(r: PriceRecordEntity, p: ProductEntity, avg: Double?) { Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(r.store.ifBlank { "Без магазина" }, fontWeight = FontWeight.SemiBold); Text(SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(r.date)), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp); r.note?.takeIf { it.isNotBlank() }?.let { Text(it, fontSize = 12.sp) } }; Column(horizontalAlignment = Alignment.End) { Text("${fmtMoney(r.price)} ₽", fontWeight = FontWeight.Bold); avg?.let { Text("${((r.price - it) / it * 100).round1()}%", color = if (r.price < it) MaterialTheme.colorScheme.primary else Color(0xFFFF7676), fontSize = 12.sp) } } } }

@Composable private fun AddPriceDialog(onDismiss: () -> Unit, onSave: (Double, String, String?) -> Unit) {
    var price by remember { mutableStateOf("") }; var store by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Добавить цену") }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { OutlinedTextField(price, { price = it }, label = { Text("Цена, ₽") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true); OutlinedTextField(store, { store = it }, label = { Text("Магазин") }, singleLine = true); OutlinedTextField(note, { note = it }, label = { Text("Заметка") }, singleLine = true) } }, confirmButton = { Button(enabled = price.toDoubleOrNull()?.let { it > 0 } == true && store.isNotBlank(), onClick = { onSave(price.replace(',', '.').toDouble(), store.trim(), note.trim().ifBlank { null }) }) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
}

@Composable private fun AlertDialogPrice(initial: Double?, enabled: Boolean, onDismiss: () -> Unit, onSave: (Double, Boolean) -> Unit) { var target by remember { mutableStateOf(initial?.toString() ?: "80") }; var isEnabled by remember { mutableStateOf(enabled) }; AlertDialog(onDismissRequest = onDismiss, title = { Text("Ценовой будильник") }, text = { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) { OutlinedTextField(target, { target = it }, label = { Text("Уведомить при цене ≤") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)); Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(isEnabled, { isEnabled = it }); Text("Будильник включён") } } }, confirmButton = { Button(enabled = target.replace(',', '.').toDoubleOrNull()?.let { it > 0 } == true, onClick = { onSave(target.replace(',', '.').toDouble(), isEnabled) }) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }) }

@Composable private fun ManualProductScreen(barcode: String, onBack: () -> Unit, onSave: (String, String?, Double?, String?) -> Unit) { var name by remember { mutableStateOf("") }; var brand by remember { mutableStateOf("") }; var qty by remember { mutableStateOf("") }; var unit by remember { mutableStateOf("шт") }; Column(Modifier.fillMaxSize()) { TopAppBar(title = { Text("Новый товар", fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.Close, null) } }); Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { Text("Штрихкод: $barcode", color = MaterialTheme.colorScheme.onSurfaceVariant); OutlinedTextField(name, { name = it }, label = { Text("Название") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(brand, { brand = it }, label = { Text("Бренд") }, modifier = Modifier.fillMaxWidth()); Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { OutlinedTextField(qty, { qty = it }, label = { Text("Количество") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f)); OutlinedTextField(unit, { unit = it }, label = { Text("Единица") }, modifier = Modifier.weight(1f)) }; Button(enabled = name.isNotBlank(), onClick = { onSave(name.trim(), brand.trim().ifBlank { null }, qty.replace(',', '.').toDoubleOrNull(), unit.trim().ifBlank { null }) }, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("Создать товар") } } } }

@Composable private fun ShoppingScreen(items: List<ShoppingListItemEntity>, onBack: () -> Unit, onToggle: (ShoppingListItemEntity) -> Unit, onDelete: (ShoppingListItemEntity) -> Unit) { Column(Modifier.fillMaxSize()) { TopAppBar(title = { Text("Список покупок", fontWeight = FontWeight.Bold) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }); LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { if (items.isEmpty()) item { EmptyState("Добавляй товары из карточки") }; items(items, key = { it.id }) { item -> Card(shape = RoundedCornerShape(16.dp)) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Checkbox(item.completed, { onToggle(item) }); Text(item.name, Modifier.weight(1f), fontWeight = FontWeight.Medium); IconButton(onClick = { onDelete(item) }) { Icon(Icons.Default.DeleteOutline, null) } } } } } } }

@Composable private fun EmptyState(text: String) { Box(Modifier.fillMaxWidth().padding(36.dp), contentAlignment = Alignment.Center) { Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center) } }

@Composable
private fun ScannerScreen(enabled: Boolean, onBack: () -> Unit, onBarcode: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    var handled by remember { mutableStateOf(false) }
    val scanner = remember {
        val options = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E)
            .build()
        BarcodeScanning.getClient(options)
    }

    DisposableEffect(previewView, enabled) {
        val pv = previewView
        if (!enabled || pv == null) return@DisposableEffect onDispose { }
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            runCatching {
                val provider = future.get()
                val preview = Preview.Builder().build()
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setTargetResolution(android.util.Size(1280, 720))
                    .build()
                analysis.setAnalyzer(ContextCompat.getMainExecutor(context)) { proxy ->
                    val image = proxy.image
                    if (image == null) { proxy.close(); return@setAnalyzer }
                    val input = InputImage.fromMediaImage(image, proxy.imageInfo.rotationDegrees)
                    scanner.process(input)
                        .addOnSuccessListener { codes ->
                            val code = codes.firstOrNull()?.rawValue
                            if (!handled && !code.isNullOrBlank()) {
                                handled = true
                                onBarcode(code)
                            }
                        }
                        .addOnCompleteListener { proxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                preview.setSurfaceProvider(pv.surfaceProvider)
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            runCatching { future.get().unbindAll() }
            scanner.close()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx -> PreviewView(ctx).also { previewView = it } },
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier.fillMaxWidth().padding(24.dp).height(280.dp)
                .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(26.dp))
                .align(Alignment.Center)
        )
        TopAppBar(
            title = { Text("Сканирование", color = Color.White) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.Close, null, tint = Color.White) } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
        )
        Text(
            "Наведите камеру на EAN-13 / EAN-8 / UPC",
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 44.dp),
            color = Color.White
        )
    }
}

private fun assess(current: Double?, avg: Double?): Pair<String, Color> { if (current == null || avg == null) return "Нет истории" to Color.White; val delta = (current - avg) / avg; return when { delta <= -0.15 -> "🔥 Очень выгодно" to Color(0xFF7CFF6B); delta <= -0.05 -> "🟢 Выгодно" to Color(0xFF9BE68E); delta >= 0.15 -> "🔴 Дорого" to Color(0xFFFF6F6F); else -> "🟡 Обычно" to Color(0xFFFFD66B) } }
private fun unitPrice(price: Double?, p: ProductEntity): Double? { val q = p.quantity ?: return null; if (q <= 0 || price == null) return null; return when (p.unit?.lowercase()) { "g" -> price / (q / 1000.0); "ml" -> price / (q / 1000.0); "kg", "l", "шт", "pcs", "piece" -> price / q; else -> null } }
private fun fmtMoney(v: Double) = String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
private fun fmt(v: Double) = String.format(Locale.US, "%.2f", v).trimEnd('0').trimEnd('.')
private fun Double.round1() = String.format(Locale.US, "%.1f", this)
