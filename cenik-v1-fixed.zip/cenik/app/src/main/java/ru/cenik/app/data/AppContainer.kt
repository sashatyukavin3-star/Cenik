package ru.cenik.app.data

import android.content.Context
import androidx.room.Room
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType

class AppContainer(context: Context) {
    val database: AppDatabase = Room.databaseBuilder(
        context, AppDatabase::class.java, "cenik.db"
    ).fallbackToDestructiveMigration().build()

    private val retrofit = Retrofit.Builder()
        .baseUrl("https://world.openfoodfacts.org/")
        .addConverterFactory(Json { ignoreUnknownKeys = true }.asConverterFactory("application/json".toMediaType()))
        .build()

    val api: OpenFoodFactsApi = retrofit.create(OpenFoodFactsApi::class.java)
    val repository = CenikRepository(database, api)
}
