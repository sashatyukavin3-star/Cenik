package ru.cenik.app.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [ProductEntity::class, PriceRecordEntity::class, PriceAlertEntity::class, ShoppingListItemEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun priceDao(): PriceDao
    abstract fun alertDao(): PriceAlertDao
    abstract fun shoppingDao(): ShoppingListDao
}
