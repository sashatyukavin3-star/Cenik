package ru.cenik.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "products", indices = [Index(value = ["barcode"], unique = true)])
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val barcode: String,
    val name: String,
    val brand: String? = null,
    val category: String? = null,
    val quantity: Double? = null,
    val unit: String? = null,
    val imageUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val favorite: Boolean = false
)

@Entity(tableName = "price_records", indices = [Index("productId"), Index("date")])
data class PriceRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val price: Double,
    val store: String,
    val date: Long = System.currentTimeMillis(),
    val note: String? = null
)

@Entity(tableName = "price_alerts", indices = [Index(value = ["productId"], unique = true)])
data class PriceAlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val targetPrice: Double,
    val enabled: Boolean = true
)

@Entity(tableName = "shopping_list_items", indices = [Index("productId")])
data class ShoppingListItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val name: String,
    val quantity: Double = 1.0,
    val completed: Boolean = false
)
