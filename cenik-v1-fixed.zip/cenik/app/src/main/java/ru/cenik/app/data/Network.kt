package ru.cenik.app.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

@Serializable
data class OffResponse(
    val status: Int = 0,
    val product: OffProduct? = null
)

@Serializable
data class OffProduct(
    @SerialName("product_name") val productName: String? = null,
    val brands: String? = null,
    val categories: String? = null,
    val quantity: String? = null,
    @SerialName("image_url") val imageUrl: String? = null
)

interface OpenFoodFactsApi {
    @Headers("User-Agent: Cenik/1.0 (Android; price radar app)")
    @GET("api/v2/product/{barcode}")
    suspend fun getProduct(
        @Path("barcode") barcode: String,
        @Query("fields") fields: String = "code,product_name,brands,categories,quantity,image_url"
    ): OffResponse
}
