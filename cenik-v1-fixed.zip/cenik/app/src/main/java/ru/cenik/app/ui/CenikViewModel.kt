package ru.cenik.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ru.cenik.app.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CenikViewModel(private val repo: CenikRepository) : ViewModel() {
    val products = repo.observeProducts()
    val favorites = repo.observeFavorites()
    val shopping = repo.observeShopping()

    private val _selectedId = MutableStateFlow<Long?>(null)
    val selectedId: StateFlow<Long?> = _selectedId.asStateFlow()

    fun selectProduct(id: Long) { _selectedId.value = id }
    fun product(id: Long) = repo.observeProduct(id)
    fun prices(id: Long) = repo.observePrices(id)
    fun alert(id: Long) = repo.observeAlert(id)
    fun search(q: String) = repo.searchProducts(q)

    fun loadBarcode(barcode: String, onResult: (Long?) -> Unit) = viewModelScope.launch {
        val normalized = barcode.filter(Char::isDigit)
        if (normalized.length !in 8..14) { onResult(null); return@launch }
        val local = repo.productByBarcode(normalized)
        if (local != null) { onResult(local.id); return@launch }
        val remote = repo.lookupRemote(normalized)
        val id = if (remote != null) repo.saveProduct(remote) else null
        onResult(id)
    }

    fun createManual(barcode: String, name: String, brand: String?, quantity: Double?, unit: String?, onSaved: (Long) -> Unit) = viewModelScope.launch {
        val id = repo.saveProduct(ProductEntity(barcode = barcode, name = name, brand = brand, quantity = quantity, unit = unit))
        onSaved(id)
    }

    fun addPrice(productId: Long, price: Double, store: String, note: String?) = viewModelScope.launch {
        repo.addPrice(productId, price, store, System.currentTimeMillis(), note)
    }

    fun toggleFavorite(product: ProductEntity) = viewModelScope.launch { repo.toggleFavorite(product) }
    fun setAlert(productId: Long, target: Double, enabled: Boolean) = viewModelScope.launch { repo.setAlert(productId, target, enabled) }
    fun addShopping(product: ProductEntity) = viewModelScope.launch { repo.addShopping(ShoppingListItemEntity(productId = product.id, name = product.name)) }
    fun updateShopping(item: ShoppingListItemEntity) = viewModelScope.launch { repo.updateShopping(item) }
    fun deleteShopping(item: ShoppingListItemEntity) = viewModelScope.launch { repo.deleteShopping(item) }

    class Factory(private val repo: CenikRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = CenikViewModel(repo) as T
    }
}
