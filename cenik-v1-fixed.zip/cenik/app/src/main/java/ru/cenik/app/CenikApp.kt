package ru.cenik.app

import android.app.Application
import ru.cenik.app.data.AppContainer

class CenikApp : Application() {
    val container by lazy { AppContainer(this) }
}
